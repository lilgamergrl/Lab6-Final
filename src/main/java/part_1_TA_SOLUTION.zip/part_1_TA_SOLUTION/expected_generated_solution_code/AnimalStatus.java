package part_1_TA_SOLUTION.expected_generated_solution_code;

public enum AnimalStatus {
    AVAILABLE,
    ADOPTED,
    MEDICAL_HOLD,
    RESERVED
}
