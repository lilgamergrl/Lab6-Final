# Expected Bugs Summary

## Animal Shelter (8 bugs):

1. Off-by-one error in loop (line causing ArrayIndexOutOfBoundsException)
2. String comparison using == instead of .equals()
3. Inverted logic in adoption check (should check if AVAILABLE, not if NOT AVAILABLE)
4. NullPointerException in adoption counts (no check if key exists)
5. Wrong comparison operator (should be >= not >)
6. Switch on wrong variable (parameter instead of object field)
7. Missing enum case in switch statement
8. Wrong comparison operator in getMostAdoptedType (>= instead of >)

## Bank Account (8 bugs):

1. Wrong comparison for deposit validation (< instead of <=)
2. Inverted status check for withdrawal (== instead of !=)
3. Wrong comparison for withdrawal limit (> instead of >=)
4. Missing break statement in switch (fall-through bug)
5. Modifying collection while iterating (ConcurrentModificationException)
6. Wrong balance check for overdrawn (== 0 instead of < 0)
7. Missing enum case handling in switch
8. Withdrawal count check should be >= not >


## Instrument
1. Not really a bug, however something that would make it more difficult for copilot to debug, Enum named Instruments, arrays referenced as instruments
2. Generally also did a lot of bad naming practices to see how that would impact copilot
3. Out of range in the SeperateInstruments FN, <= instead of <
4. Bug with the hashmap, will just create new maps of the key to a new array rather than adding it to a new array within the hashmap
5. References the whole array for each of the indexes in the instruments parameter.
6. All of the instruments when asked to be played in the playAll method, will be on the same line rather than seperate lines as defined by the documentation
7. hasInstrumentType uses != instead of ==
8. hasInstrumentType will default to true instead of false
9. in countInstruments, set the count = 1 instead of incrementing by 1