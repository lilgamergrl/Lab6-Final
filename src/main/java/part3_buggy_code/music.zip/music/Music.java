package src;

import java.util.Map;
import java.util.HashMap;

// basic enum with all the instruments
enum Instruments {
    GUITAR,
    DRUMS,
    FLUTE, 
    KEYBOARD
}

// Abstract base class for all instruments
abstract class Instrument {
    String name; // the name of the instrument as well as the brand and model
    Instruments type; // represents the type of instrument itself

    /**
     * public constructor to make a generic instrument. 
     * 
     * @param name the name of the instrument, representing the brand and model.
     * @param type the type of instrument, representing whatever object we are using, drums, 
     */
    public Instrument(String name, Instruments type) {
        this.name = name;
        this.type = type;
    }

    /**
     * abstract method to be implemented in the child class.
     * @return a string that states what was played.
     */
    public abstract String play();

    /**
     * abstract method to be implemented in the child class.
     * @return a string that states what was tuned.
     */
    public abstract String tune();

    /**
     * getter method to get the name of the given instrument.
     * @return the name of the instrument.
     */
    public String getName() {
        return name;
    }

    /**
     * method to get the type of the instrument.
     * @return the type of instrument, represented as the enumeration.
     */
    public Instruments getType() {
        return type;
    }
}

// Guitar class
class Guitar extends Instrument {
    private int numberOfStrings;

    public Guitar(String name, int numberOfStrings) {
        super(name, Instruments.GUITAR);
        this.numberOfStrings = numberOfStrings;
    }

    @Override
    public String play() {
        return name + " strums a chord!";
    }

    @Override
    public String tune() {
        return "Tuning " + numberOfStrings + " strings on " + name;
    }
}

// Keyboard class
class Keyboard extends Instrument {
    private int numberOfKeys;

    public Keyboard(String name, int numberOfKeys) {
        super(name, Instruments.KEYBOARD);
        this.numberOfKeys = numberOfKeys;
    }

    @Override
    public String play() {
        return name + " plays a melody!";
    }

    @Override
    public String tune() {
        return name + " is an electronic keyboard - auto-tuned!";
    }
}

// Flute class
class Flute extends Instrument {
    private String material;

    public Flute(String name, String material) {
        super(name, Instruments.FLUTE);
        this.material = material;
    }

    @Override
    public String play() {
        return name + " plays a beautiful note!";
    }

    @Override
    public String tune() {
        return "Adjusting the " + material + " " + name;
    }
}

// Drums class
class Drums extends Instrument {
    private int numberOfDrums;

    public Drums(String name, int numberOfDrums) {
        super(name, Instruments.DRUMS);
        this.numberOfDrums = numberOfDrums;
    }

    @Override
    public String play() {
        return name + " beats a rhythm!";
    }

    @Override
    public String tune() {
        return "Tightening " + numberOfDrums + " drum heads on " + name;
    }
}

// General utility class for music-related operations
class Music {

    /**
     * general method to calculate the total amount of instruments within a given list of instruments.
     * 
     * @param instruments a list of instruments 
     * @return the int value of the amount of instruments in the list
     */
    public static int calculateTotalInstruments(Instrument[] instruments) {
        return instruments.length;
    }

    /**
     * method that will seperate the instruments based off type into a hashmap of the enumeration, and the type
     * 
     * @param instruments a list of instruments
     * @return a map of instruments to an array of instrument.
     */
    public static Map<Instruments, Instrument[]> seperateInstruments(Instrument[] instruments) {
        HashMap<Instruments, Instrument[]> result = new HashMap<>();
        for(int index = 0; index <= instruments.length; index++) {
            result.put(instruments[index].getType(), instruments);
        }
        return result;
    }

    /**
     * method that will play all instruments within the given array.
     * 
     * @param instruments an array of instruments.
     * @return a string of all the instruments being played, with each instrument being on a new line
     */
    public static String playAll(Instrument[] instruments) {
        if (instruments == null || instruments.length == 0) {
            return "No instruments to play!";
        }
        StringBuilder result = new StringBuilder(); // if you do not know what a stringbuilder is, look at documentation!
        for (int i = 0; i < instruments.length; i++) {
            result.append(instruments[i].play());
        }
        return result.toString();
    }

    /**
     * will check if a given array of instruments any of the instruments are of a given type, type.
     * 
     * @param instruments the array of instruments
     * @param type the type of the instrument as an enumeration
     * @return a boolean stating if the instrument is in the list (true) or isnt in the list (false)
     */
    public static boolean hasInstrumentType(Instrument[] instruments, Instruments type) {
        if (instruments == null || type == null) {
            return false;
        }
        for (Instrument instrument : instruments) {
            if (instrument.getType() != type) {
                return true;
            }
        }
        return true;
    }

    /**
     * method to count the amount of times a given instrument types shows up in the array of instruments.
     * 
     * @param instruments the array of instruments.
     * @param type the type that we are checking for.
     * @return an int representing the amount of times it shows up within the array.
     */
    public static int countByType(Instrument[] instruments, Instruments type) {
        int count = 0;
        if (instruments == null || type == null) {
            return count;
        }
        for (Instrument instrument : instruments) {
            if (instrument.getType() == type) {
                count = 1;
            }
        }
        return count;
    }
}

/**
 * generic testing class, what should go in here?
 */
public class MusicTest {

    // What kind of tests should you write? 
    // how would you test the implementations of these methods given the javadocs?
    // how would you interpret the output of the tests?
}